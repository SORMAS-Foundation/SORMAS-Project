package sormas

import scala.concurrent.duration._

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._

class RESTInfrastructureSimulation extends Simulation {

	val scn = scenario("RESTInfrastructureSimulation")
		.group("Request Infrastructure Data") {
			exec(http("get_regions")
				.get("/sormas-rest/regions/all/0")
				.basicAuth(SimulationConfig.mobileUsername,SimulationConfig.mobilePassword)
				.check(status.is(200)))
			.exec(http("get_districts")
				.get("/sormas-rest/districts/all/0")
				.basicAuth(SimulationConfig.mobileUsername,SimulationConfig.mobilePassword)
				.check(status.is(200)))
			.exec(http("get_communities")
				.get("/sormas-rest/communities/all/0")
				.basicAuth(SimulationConfig.mobileUsername,SimulationConfig.mobilePassword)
				.check(status.is(200)))
			.exec(http("get_facilities")
				.get("/sormas-rest/facilities/region/0/0")
				.basicAuth(SimulationConfig.mobileUsername,SimulationConfig.mobilePassword)
				.check(status.is(200)))
		}

	setUp(scn.inject(atOnceUsers(SimulationConfig.numberOfUsers))).protocols(SimulationConfig.httpProtocol)
	
}