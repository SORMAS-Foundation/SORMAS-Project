package sormas

import scala.concurrent.duration._

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._

object SimulationConfig {

	var serverUrl = "https://sormas.symeda.de"

	val mobileUsername = "SanaObas"
	val mobilePassword = "Azga3XPKAeBc"
	
	// The amount of users that are simulated to do the requests specified in the simulations either
	// at once (for REST calls) or over a certain duration (for UI tests)
	val numberOfUsers = 20
	
	// The amount of seconds over which the number of users are injected into simulations that are used
	// to test parts of the UI
	val numberOfUsersDuration = 10
	
	val httpProtocol = http
		.baseUrl(serverUrl)
		.inferHtmlResources(BlackList(""".*\.js""", """.*\.css""", """.*\.gif""", """.*\.jpeg""", """.*\.jpg""", """.*\.ico""", """.*\.woff""", """.*\.woff2""", """.*\.(t|o)tf""", """.*\.png""", """.*detectportal\.firefox\.com.*"""), WhiteList())
		.acceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
		.acceptEncodingHeader("gzip, deflate")
		.acceptLanguageHeader("de,en-US;q=0.7,en;q=0.3")
		.upgradeInsecureRequestsHeader("1")
		.userAgentHeader("Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:66.0) Gecko/20100101 Firefox/66.0")

}