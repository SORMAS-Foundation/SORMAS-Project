package sormas

import scala.concurrent.duration._

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._

class DashboardSimulation extends Simulation {

	val headers_0 = Map(
		"Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
		"Upgrade-Insecure-Requests" -> "1")
	val headers_1 = Map("Accept" -> "text/css,*/*;q=0.1")
	val headers_4 = Map("Content-Type" -> "application/json; charset=UTF-8")

	val scn = scenario("DashboardSimulation")
		.group("Open Dashboard") {
			exec(http("request_css")
				.get("/sormas-ui/")
				.headers(headers_0)
				.resources(http("request_css_resources")
				.get("/sormas-ui/VAADIN/themes/sormas/styles.css?v=8.7.1")
				.headers(headers_1),
				http("dashboard_request_widgetset")
				.get("/sormas-ui/VAADIN/widgetsets/de.symeda.sormas.SormasWidgetset/de.symeda.sormas.SormasWidgetset.nocache.js?1559896678716"),
				http("request_ui")
				.post("/sormas-ui/?v-1559896678717")
				.formParam("v-browserDetails", "1")
				.formParam("theme", "sormas")
				.formParam("v-appId", "sormasui-1655777373")
				.formParam("v-sh", "1080")
				.formParam("v-sw", "1920")
				.formParam("v-cw", "1920")
				.formParam("v-ch", "944")
				.formParam("v-curdate", "1559896678717")
				.formParam("v-tzo", "-120")
				.formParam("v-dstd", "60")
				.formParam("v-rtzo", "-60")
				.formParam("v-dston", "true")
				.formParam("v-tzid", "Europe/Berlin")
				.formParam("v-vw", "1920")
				.formParam("v-vh", "0")
				.formParam("v-loc", "https://sormas.symeda.de/sormas-ui/#!dashboard")
				.formParam("v-wn", "sormasui-1655777373-0.33641459708811094")))
			.pause(1)
			.exec(http("request_dashboard")
				.post("/sormas-ui/UIDL/?v-uiId=6")
				.headers(headers_4)
				.body(RawFileBody("sormas/DashboardSimulation/0004_request.json")))
		}

	setUp(scn.inject(rampUsers(SimulationConfig.numberOfUsers) during (SimulationConfig.numberOfUsersDuration seconds))).protocols(SimulationConfig.httpProtocol)
}