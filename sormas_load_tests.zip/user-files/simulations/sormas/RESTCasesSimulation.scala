package sormas

import scala.concurrent.duration._

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._

class RESTCasesSimulation extends Simulation {

	val scn = scenario("RESTCasesSimulation")
		.exec(http("get_cases")
			.get("/sormas-rest/cases/all/0")
			.basicAuth(SimulationConfig.mobileUsername,SimulationConfig.mobilePassword)
			.check(status.is(200)))

	setUp(scn.inject(atOnceUsers(SimulationConfig.numberOfUsers))).protocols(SimulationConfig.httpProtocol)
	
}