package sormas

import scala.concurrent.duration._

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._

class RESTPersonsSimulation extends Simulation {

	val scn = scenario("RESTPersonsSimulation")
		.exec(http("get_persons")
			.get("/sormas-rest/persons/all/0")
			.basicAuth(SimulationConfig.mobileUsername,SimulationConfig.mobilePassword)
			.check(status.is(200)))

	setUp(scn.inject(atOnceUsers(SimulationConfig.numberOfUsers))).protocols(SimulationConfig.httpProtocol)
	
}